This LaTeX template (unofficial) allows the production of slides presentation of the Federal University of Technology — Paraná (UTFPR). It was developed based on the abnTeX2 (https://www.abntex.net.br/) slides presentation template created by Fabio Rodrigues Silva, using the beamer LaTeX class (https://ctan.org/pkg/beamer/). Also, several code snippets developed by users of the TeX-LaTeX Stack Exchange (https://tex.stackexchange.com) were used.

Status: added by Luiz E. M. Lima, maintenance on demand.
Last updated: October 5, 2024 (Version 1.5).


Este modelo LaTeX (não oficial) permite a produção de apresentação de slides da Universidade Tecnológica Federal do Paraná (UTFPR). Foi desenvolvido baseado no modelo de apresentação de slides do abnTeX2 (https://www.abntex.net.br/) criado por Fábio Rodrigues Silva, usando a classe LaTeX beamer (https://ctan.org/pkg/beamer/). Além disso, diversos trechos de códigos desenvolvidos por usuários do TeX-LaTeX Stack Exchange (https://tex.stackexchange.com) foram usados.

Estado: adicionado por Luiz E. M. Lima, manutenção sob demanda.
Última atualização: 5 de outubro de 2024 (Versão 1.5).
